from __future__ import annotations

import csv
import html
import io
import json
import sqlite3
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, urlparse

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "cleaned_data.db"
STYLE_PATH = BASE_DIR / "static" / "style.css"


def init_db() -> None:
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS records (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                raw_payload TEXT NOT NULL,
                cleaned_payload TEXT NOT NULL,
                row_count INTEGER NOT NULL
            )
            """
        )


def parse_rows(raw_data: str, input_format: str) -> list[dict[str, Any]]:
    if input_format == "json":
        parsed = json.loads(raw_data)
        if not isinstance(parsed, list):
            raise ValueError("JSON data must be an array of objects.")
        if parsed and not isinstance(parsed[0], dict):
            raise ValueError("JSON array must contain objects.")
        return [dict(row) for row in parsed]

    reader = csv.DictReader(io.StringIO(raw_data))
    rows = [dict(row) for row in reader]
    if not rows:
        raise ValueError("CSV must include a header and at least one data row.")
    return rows


def clean_sort_data(rows: list[dict[str, Any]], sort_by: str) -> list[dict[str, Any]]:
    cleaned_rows: list[dict[str, Any]] = []
    seen: set[tuple[tuple[str, str], ...]] = set()

    for row in rows:
        normalized = {
            key.strip().lower().replace(" ", "_"): str(value).strip()
            for key, value in row.items()
            if key is not None and value is not None
        }
        signature = tuple(sorted(normalized.items()))
        if signature in seen:
            continue
        seen.add(signature)
        cleaned_rows.append(normalized)

    if not cleaned_rows:
        raise ValueError("No valid rows were found after cleaning.")

    normalized_sort_key = sort_by.strip().lower().replace(" ", "_")
    if normalized_sort_key not in cleaned_rows[0]:
        raise ValueError(f"Sort field '{sort_by}' does not exist in the data.")

    cleaned_rows.sort(key=lambda row: row.get(normalized_sort_key, "").lower())
    return cleaned_rows


def save_dataset(raw_payload: str, cleaned_rows: list[dict[str, Any]]) -> None:
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute(
            "INSERT INTO records (raw_payload, cleaned_payload, row_count) VALUES (?, ?, ?)",
            (raw_payload, json.dumps(cleaned_rows), len(cleaned_rows)),
        )


def fetch_datasets() -> list[dict[str, Any]]:
    with sqlite3.connect(DB_PATH) as conn:
        rows = conn.execute(
            "SELECT id, cleaned_payload, row_count FROM records ORDER BY id DESC"
        ).fetchall()
    return [
        {"id": row[0], "cleaned_payload": json.loads(row[1]), "row_count": row[2]}
        for row in rows
    ]


def render_page(content: str) -> bytes:
    return f"""<!DOCTYPE html>
<html lang='en'>
  <head>
    <meta charset='UTF-8'/>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'/>
    <title>Auto Data Cleaner</title>
    <link rel='stylesheet' href='/static/style.css'/>
  </head>
  <body><main class='container'>{content}</main></body>
</html>""".encode("utf-8")


def home_content(error: str | None = None, cleaned_rows: list[dict[str, Any]] | None = None) -> str:
    error_html = f"<p class='error'>{html.escape(error)}</p>" if error else ""
    output_html = ""
    if cleaned_rows:
        output_html = (
            f"<section class='card'><h2>Cleaned output ({len(cleaned_rows)} rows)</h2>"
            f"<pre>{html.escape(json.dumps(cleaned_rows, indent=2))}</pre></section>"
        )

    return f"""
      <h1>Auto Data Cleaner</h1>
      <p class='subtitle'>Paste JSON or CSV data and the app will clean, sort, and store it.</p>
      <form method='post' class='card'>
        <label for='input_format'>Input format</label>
        <select name='input_format' id='input_format'>
          <option value='json'>JSON array</option>
          <option value='csv'>CSV</option>
        </select>
        <label for='sort_by'>Sort by field</label>
        <input id='sort_by' name='sort_by' placeholder='name' required />
        <label for='raw_data'>Data payload</label>
        <textarea id='raw_data' name='raw_data' rows='12' required></textarea>
        <button type='submit'>Clean + Sort + Store</button>
      </form>
      {error_html}
      {output_html}
      <a href='/history' class='link'>View stored datasets</a>
    """


def history_content() -> str:
    cards = []
    for dataset in fetch_datasets():
        cards.append(
            f"<section class='card'><h2>Dataset #{dataset['id']} ({dataset['row_count']} rows)</h2>"
            f"<pre>{html.escape(json.dumps(dataset['cleaned_payload'], indent=2))}</pre></section>"
        )
    if not cards:
        cards.append("<p>No datasets saved yet.</p>")
    return "<h1>Stored Datasets</h1>" + "".join(cards) + "<a href='/' class='link'>Back</a>"


class AppHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        route = urlparse(self.path).path
        if route == "/":
            self.respond(HTTPStatus.OK, render_page(home_content()))
        elif route == "/history":
            self.respond(HTTPStatus.OK, render_page(history_content()))
        elif route == "/static/style.css":
            css = STYLE_PATH.read_bytes()
            self.respond(HTTPStatus.OK, css, content_type="text/css")
        else:
            self.respond(HTTPStatus.NOT_FOUND, b"Not Found", "text/plain")

    def do_POST(self):
        length = int(self.headers.get("Content-Length", "0"))
        body = self.rfile.read(length).decode("utf-8")
        form = parse_qs(body)

        raw_data = form.get("raw_data", [""])[0]
        input_format = form.get("input_format", ["json"])[0]
        sort_by = form.get("sort_by", [""])[0]

        try:
            parsed_rows = parse_rows(raw_data, input_format)
            cleaned = clean_sort_data(parsed_rows, sort_by)
            save_dataset(raw_data, cleaned)
            self.respond(HTTPStatus.OK, render_page(home_content(cleaned_rows=cleaned)))
        except Exception as exc:
            self.respond(HTTPStatus.BAD_REQUEST, render_page(home_content(error=str(exc))))

    def respond(self, status, body, content_type="text/html"):
        self.send_response(status)
        self.send_header("Content-Type", f"{content_type}; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


def run_server(port: int = 5000):
    init_db()
    server = ThreadingHTTPServer(("0.0.0.0", port), AppHandler)
    print(f"Serving on http://0.0.0.0:{port}")
    server.serve_forever()


if __name__ == "__main__":
    run_server()
