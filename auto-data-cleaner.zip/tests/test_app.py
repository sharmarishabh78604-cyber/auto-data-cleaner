import unittest
from app import clean_sort_data, parse_rows

class AppTestCase(unittest.TestCase):
    def test_json_data_cleaning_and_sorting(self):
        rows = parse_rows(
            '[{"Name": " Zoe", "Age": "20"}, {"Name": "ana", "Age": "22"}, {"Name": "ana", "Age": "22"}]',
            "json",
        )
        cleaned = clean_sort_data(rows, "name")
        self.assertEqual(len(cleaned), 2)

if __name__ == "__main__":
    unittest.main()
